package com.craftinginterpreters.lox;

abstract class Expr2 {
    static class Literal extends Expr2 {
        Literal(Object value) {this.value = value}

    }
    static class Unary extends Expr2 {
        Unary(Token token, Expr2 rigth) {
            this.operator = token;
            this.rigth = rigth;
        }
        final Token operator;
        final Expr2 rigth;
    }
    static class Grouping extends Expr2 {
        Grouping(Expr2 expression) {

        }
    }
    static class Binary extends Expr2 {
        Binary(Expr2 left, Token operator, Expr2 right) {
            this.left = left;
            this.operator = operator;
            this.right = right;
        }
        final Expr2 left;
        final Token operator;
        final Expr2 right;

    }


}

