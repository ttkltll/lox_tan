package com.craftinginterpreters.lox;

public class Parser2 {
   Expr2 parser(){
        return equals();
    }
   Expr2 equals() {
       Expr2 expression = term();
       Token operator = previous();
       return Expr2.Binary(expression, operator, expression)
   }
   Expr2 unary() {
       Expr2 expression =
       return Expr2.Unary(operator, expression);
   }


}
